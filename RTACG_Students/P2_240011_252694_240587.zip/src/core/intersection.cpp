#include "intersection.h"

Intersection::Intersection()
{

}

